<!DOCTYPE html>
<html>
<head>
<title>Helen's Allowance</title>
</head>
<body  style="background-color:pink;" >


<?php
// Database connection parameters
$host = 'localhost'; // Replace with your database host
$username = 'roeweb_user'; // Replace with your MySQL username
$password = 'R0ew3b!pg0@jb'; // Replace with your MySQL password
$database = 'roe_screen'; // Replace with your database name

// Establish a connection to the database
$conn = new mysqli($host, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to fetch the current allowance
function get_current_allowance($conn, $customerID = 1) {
    $query = "SELECT Allowance FROM Accounts WHERE CustomerID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $customerID);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        return number_format($row['Allowance'], 2); // Format to 2 decimal places
    }

    return "0.00"; // Default if no record is found
}

// Function to fetch the current allowance and balance
function get_current_balance($conn, $customerID = 1) {
    $query = "SELECT Balance FROM Accounts WHERE CustomerID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $customerID);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        return number_format($row['Balance'], 2); // Format to 2 decimal places
    }

    return "0.00"; // Default if no record is found
}


// Fetch and output the allowance
echo '<span style="font-size: 50px;"><center> 
    <p>Helen\'s Allowance</p>
    <p>$' . get_current_allowance($conn).  '</p> </center> </span>';


echo '<span style="font-size: 50px;"><center> 
    <p>Helen\'s Balance</p>
    <p>$' . get_current_balance($conn).  '</p> </center> </span>';




// Close the database connection
$conn->close();
?>


<br>

</body>
</html>
